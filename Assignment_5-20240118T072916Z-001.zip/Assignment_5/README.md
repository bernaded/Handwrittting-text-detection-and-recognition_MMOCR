First, create JSON file using label-studio, whereas handwriting images as inputs

Then, input the handwritting image on google colab/visual studio code/jupyter anaconda

Build text detection and recognition model using default MMOCR and calculate CER and WER values for each images. 
It can be seen in inference_assignment2.ipynb

Construct new models with adjustable hyperparameters to compare the previous models whether it provides good result of WER and CER or not. The training steps can be seen in handwritting_training.ipynb
Several .py files required to be modified in the mmocr/configs file based on determined hyperparameters:
1. textdet--> icdar2015.py, bnet_resnet50-dcnv2_fpnc_1200e_icdar2015.py
2. textrecog--> icdar2015.py, svtr-base_20e_st_mj.py, svtr-tiny_20e_st_mj

The visualization and other training outputs are uploaded in folder assignment 5

